"""
ManageAI Remote Agent.

Install optional dependencies on the target laptop:
    pip install websockets mss pillow pyautogui

Run:
    python remote_agent.py --server ws://127.0.0.1:8001 --token DEVICE_TOKEN

For another device on the same Wi-Fi, do not use 127.0.0.1. Start Django with:
    python manage.py runserver 0.0.0.0:8001

Then use this computer's LAN IP:
    python remote_agent.py --server ws://192.168.1.10:8001 --token DEVICE_TOKEN

The agent never opens browser-local disk access. It connects outbound to ManageAI,
waits for a dashboard session request, asks for local approval in the terminal,
then accepts screen, control, and file commands over the approved WebSocket.
"""

import argparse
import asyncio
import base64
import json
import os
import platform
import socket
import time
from pathlib import Path

try:
    import mss
    from PIL import Image
except Exception:
    mss = None
    Image = None

try:
    import pyautogui
except Exception:
    pyautogui = None

try:
    import websockets
except Exception as exc:
    raise SystemExit("Install websockets first: pip install websockets") from exc


class RemoteAgent:
    def __init__(self, server, token, fps=8):
        self.server = self.normalize_server(server)
        self.token = token
        self.fps = max(1, min(fps, 20))
        self.active_sessions = set()
        self.streaming = False

    def normalize_server(self, server):
        value = (server or "ws://127.0.0.1:8001").strip().rstrip("/")
        if value.startswith("http://"):
            return f"ws://{value.removeprefix('http://')}"
        if value.startswith("https://"):
            return f"wss://{value.removeprefix('https://')}"
        return value

    @property
    def url(self):
        return f"{self.server}/ws/remote-agent/{self.token}/"

    async def run(self):
        while True:
            try:
                async with websockets.connect(self.url, max_size=8 * 1024 * 1024) as ws:
                    await self.hello(ws)
                    heartbeat = asyncio.create_task(self.heartbeat(ws))
                    async for raw in ws:
                        await self.handle(ws, json.loads(raw))
                    heartbeat.cancel()
            except Exception as exc:
                print(f"Disconnected from {self.url}: {exc}. Reconnecting in 3s.")
                if "refused" in str(exc).lower() or "1225" in str(exc):
                    print("Tip: make sure Django is running on that host/port. For another local device, run Django with 0.0.0.0:8001 and use the server computer's LAN IP, not 127.0.0.1.")
                await asyncio.sleep(3)

    async def hello(self, ws):
        await ws.send(json.dumps({"type": "heartbeat", "metadata": self.device_metadata()}))

    async def heartbeat(self, ws):
        while True:
            await asyncio.sleep(10)
            await ws.send(json.dumps({"type": "heartbeat", "metadata": self.device_metadata()}))

    def device_metadata(self):
        return {
            "hostname": socket.gethostname(),
            "platform": platform.platform(),
            "agent_version": "0.1.0",
            "capabilities": {"screen": bool(mss), "control": bool(pyautogui), "files": True, "chunked_transfer": True},
        }

    async def handle(self, ws, message):
        kind = message.get("type")
        if kind == "session.request":
            await self.ask_approval(ws, message["session"])
        elif kind == "session.disconnect":
            self.active_sessions.discard(message.get("session_token"))
        elif kind == "session.command":
            await self.handle_command(ws, message)
        elif kind == "file.command":
            await self.handle_file(ws, message)
        elif kind == "file.transfer":
            await self.handle_transfer(ws, message)

    async def ask_approval(self, ws, session):
        token = session["token"]
        permission = session["permission"]
        print(f"\nRemote request: {permission} from {session.get('requested_by_name') or 'dashboard'}")
        answer = input("Approve this session? Type YES to approve: ").strip()
        if answer == "YES":
            self.active_sessions.add(token)
            await ws.send(json.dumps({"type": "session.approved", "session_token": token, "answer": {"transport": "websocket-frame-relay"}}))
            asyncio.create_task(self.stream_screen(ws, token))
        else:
            await ws.send(json.dumps({"type": "session.denied", "session_token": token}))

    async def stream_screen(self, ws, session_token):
        if not mss or not Image:
            await ws.send(json.dumps({"type": "agent.error", "session_token": session_token, "message": "mss and pillow are required for screen capture."}))
            return
        with mss.mss() as screen:
            monitor = screen.monitors[1]
            while session_token in self.active_sessions:
                shot = screen.grab(monitor)
                img = Image.frombytes("RGB", shot.size, shot.rgb)
                img.thumbnail((1280, 720))
                from io import BytesIO

                buf = BytesIO()
                img.save(buf, format="JPEG", quality=62, optimize=True)
                await ws.send(json.dumps({"type": "screen.frame", "session_token": session_token, "image": base64.b64encode(buf.getvalue()).decode("ascii"), "ts": time.time()}))
                await asyncio.sleep(1 / self.fps)

    async def handle_command(self, ws, message):
        if message.get("session_token") not in self.active_sessions or not pyautogui:
            return
        command = message.get("command")
        payload = message.get("payload") or {}
        if command == "mouse":
            action = payload.get("action")
            if "x_ratio" in payload and "y_ratio" in payload:
                width, height = pyautogui.size()
                x = int(float(payload["x_ratio"]) * width)
                y = int(float(payload["y_ratio"]) * height)
            else:
                x, y = int(payload.get("x", 0)), int(payload.get("y", 0))
            if action == "move":
                pyautogui.moveTo(x, y)
            elif action == "click":
                pyautogui.click(x, y)
            elif action == "scroll":
                pyautogui.scroll(int(payload.get("delta", 0)))
        elif command == "keyboard":
            text = payload.get("text")
            key = payload.get("key")
            if text:
                pyautogui.write(text)
            elif key:
                pyautogui.press(key)

    async def handle_file(self, ws, message):
        session_token = message.get("session_token")
        action = message.get("action")
        payload = message.get("payload") or {}
        try:
            if action == "drives":
                result = {"path": "Drives", "entries": [{"name": drive["name"], "path": drive["path"], "is_dir": True, "size": 0} for drive in self.drives()]}
            elif action == "list":
                result = self.list_path(payload.get("path") or self.default_root())
            elif action == "delete":
                result = self.delete_path(payload["path"])
            else:
                result = {"error": f"Unsupported file action: {action}"}
            await ws.send(json.dumps({"type": "file.result", "session_token": session_token, "action": action, "result": result}))
        except Exception as exc:
            await ws.send(json.dumps({"type": "agent.error", "session_token": session_token, "message": str(exc)}))

    async def handle_transfer(self, ws, message):
        transfer = message.get("transfer") or {}
        path = transfer.get("source_path")
        session_token = message.get("session_token")
        chunk_size = int(transfer.get("chunk_size") or 262144)
        sent = 0
        with open(path, "rb") as handle:
            while True:
                chunk = handle.read(chunk_size)
                if not chunk:
                    break
                sent += len(chunk)
                await ws.send(json.dumps({"type": "transfer.progress", "session_token": session_token, "transfer_id": transfer.get("id"), "bytes": sent, "chunk": base64.b64encode(chunk).decode("ascii")}))
        await ws.send(json.dumps({"type": "transfer.progress", "session_token": session_token, "transfer_id": transfer.get("id"), "complete": True, "bytes": sent}))

    def drives(self):
        if os.name == "nt":
            return [{"name": f"{letter}:", "path": f"{letter}:\\"} for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if Path(f"{letter}:\\").exists()]
        return [{"name": "/", "path": "/"}]

    def default_root(self):
        drives = self.drives()
        return drives[0]["path"] if drives else str(Path.home())

    def list_path(self, raw_path):
        root = Path(raw_path)
        entries = []
        for item in root.iterdir():
            try:
                stat = item.stat()
                entries.append({"name": item.name, "path": str(item), "is_dir": item.is_dir(), "size": stat.st_size, "modified": stat.st_mtime})
            except PermissionError:
                entries.append({"name": item.name, "path": str(item), "is_dir": item.is_dir(), "size": 0, "locked": True})
        return {"path": str(root), "entries": sorted(entries, key=lambda row: (not row["is_dir"], row["name"].lower()))}

    def delete_path(self, raw_path):
        path = Path(raw_path)
        if path.is_dir():
            raise PermissionError("Folder deletes are intentionally disabled in the starter agent.")
        path.unlink()
        return {"deleted": str(path)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", default="ws://127.0.0.1:8001")
    parser.add_argument("--token", required=True)
    parser.add_argument("--fps", type=int, default=8)
    args = parser.parse_args()
    asyncio.run(RemoteAgent(args.server, args.token, args.fps).run())


if __name__ == "__main__":
    main()
