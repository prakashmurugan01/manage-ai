from datetime import timedelta
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone

from apps.notifications.models import Notification

from .health import HealthProbeResult
from .models import HostedProject, HostingLifecycle, HostingLink
from .tasks import check_hosted_project_health
from .providers import toggle_hosted_project_access


class HostedProjectAccessTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.admin = User.objects.create_user(
            username="admin",
            email="admin@example.com",
            password="password",
            role=User.Role.ADMIN,
            is_staff=True,
        )
        self.project = HostedProject.objects.create(
            name="Example App",
            client_name="Example Client",
            domain="example-app.test",
            hosting_platform=HostedProject.Platform.NETLIFY,
            deploy_url="https://example-app.test",
            status=HostedProject.Status.LIVE,
            tag="active",
            link_is_active=True,
            expiry_date=timezone.localdate() + timedelta(days=365),
        )
        self.link = HostingLink.objects.create(
            project=self.project,
            provider=HostingLink.Provider.NETLIFY,
            label="Primary",
            url="https://example-app.test",
            domain="example-app.test",
            status=HostingLink.Status.ON,
            is_active=True,
            is_enabled=True,
        )

    @patch("apps.hosting.providers.toggle_hosting_link")
    def test_disable_updates_project_links_lifecycle_and_notifications(self, toggle_link):
        def fake_toggle(link, enabled, user=None):
            link.is_enabled = enabled
            link.status = HostingLink.Status.ON if enabled else HostingLink.Status.OFF
            link.save(update_fields=["is_enabled", "status", "updated_at"])
            return link

        toggle_link.side_effect = fake_toggle
        toggle_hosted_project_access(self.project, False, user=self.admin, reason="Maintenance window")

        self.project.refresh_from_db()
        self.link.refresh_from_db()

        self.assertFalse(self.project.link_is_active)
        self.assertEqual(self.project.status, HostedProject.Status.DISABLED)
        self.assertEqual(self.project.tag, "disabled")
        self.assertFalse(self.link.is_enabled)
        self.assertEqual(self.link.status, HostingLink.Status.OFF)
        self.assertTrue(
            HostingLifecycle.objects.filter(
                project=self.project,
                event_type=HostingLifecycle.Event.LINK_DISABLED,
            ).exists()
        )
        self.assertTrue(
            Notification.objects.filter(
                recipient=self.admin,
                hosted_project=self.project,
                title="Hosting disabled",
            ).exists()
        )

    @patch("apps.hosting.providers.toggle_hosting_link")
    def test_enable_restores_active_status(self, toggle_link):
        def fake_toggle(link, enabled, user=None):
            link.is_enabled = enabled
            link.status = HostingLink.Status.ON if enabled else HostingLink.Status.OFF
            link.save(update_fields=["is_enabled", "status", "updated_at"])
            return link

        toggle_link.side_effect = fake_toggle
        toggle_hosted_project_access(self.project, False, user=self.admin)
        toggle_hosted_project_access(self.project, True, user=self.admin)

        self.project.refresh_from_db()
        self.link.refresh_from_db()

        self.assertTrue(self.project.link_is_active)
        self.assertEqual(self.project.status, HostedProject.Status.LIVE)
        self.assertEqual(self.project.tag, "active")
        self.assertTrue(self.link.is_enabled)
        self.assertEqual(self.link.status, HostingLink.Status.ON)


class HostingHealthCheckTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.admin = User.objects.create_user(
            username="health-admin",
            email="health-admin@example.com",
            password="password",
            role=User.Role.ADMIN,
            is_staff=True,
        )
        self.project = HostedProject.objects.create(
            name="Vercel Preview",
            client_name="Vercel",
            domain="index-62b346a6v-prakash-murugans-projects.vercel.app",
            hosting_platform=HostedProject.Platform.VERCEL,
            deploy_url="https://index-62b346a6v-prakash-murugans-projects.vercel.app",
            status=HostedProject.Status.LIVE,
            tag="active",
            link_is_active=True,
            expiry_date=timezone.localdate() + timedelta(days=365),
        )

    @patch("apps.hosting.tasks.probe_url")
    def test_redirect_is_online(self, probe):
        probe.return_value = HealthProbeResult(
            url=self.project.deploy_url,
            final_url=f"{self.project.deploy_url}/login",
            status_code=302,
            response_time_ms=180,
            online=True,
            dns_ok=True,
            ssl_ok=True,
            redirect_chain=[self.project.deploy_url],
        )

        check_hosted_project_health(self.project.id)
        self.project.refresh_from_db()

        self.assertEqual(self.project.server_status, HostedProject.ServerStatus.ONLINE)
        self.assertTrue(self.project.link_is_active)
        self.assertEqual(self.project.downtime_count, 0)

    @patch("apps.hosting.tasks.probe_url")
    def test_alert_waits_for_three_consecutive_failures(self, probe):
        probe.return_value = HealthProbeResult(
            url=self.project.deploy_url,
            status_code=404,
            response_time_ms=210,
            online=False,
            dns_ok=True,
            ssl_ok=True,
            error="HTTP 404",
        )

        check_hosted_project_health(self.project.id)
        check_hosted_project_health(self.project.id)

        self.project.refresh_from_db()
        self.assertEqual(self.project.server_status, HostedProject.ServerStatus.OFFLINE)
        self.assertTrue(self.project.link_is_active)
        self.assertEqual(Notification.objects.filter(hosted_project=self.project, title__icontains="offline").count(), 0)

        check_hosted_project_health(self.project.id)

        self.assertEqual(Notification.objects.filter(hosted_project=self.project, title__icontains="offline").count(), 1)
        self.assertTrue(self.project.incidents.filter(status="open").exists())

    @patch("apps.hosting.tasks.probe_url")
    def test_recovery_closes_open_incident(self, probe):
        probe.return_value = HealthProbeResult(
            url=self.project.deploy_url,
            status_code=500,
            response_time_ms=300,
            online=False,
            dns_ok=True,
            ssl_ok=True,
            error="HTTP 500",
        )
        for _ in range(3):
            check_hosted_project_health(self.project.id)

        probe.return_value = HealthProbeResult(
            url=self.project.deploy_url,
            status_code=204,
            response_time_ms=90,
            online=True,
            dns_ok=True,
            ssl_ok=True,
        )
        check_hosted_project_health(self.project.id)

        self.project.refresh_from_db()
        self.assertEqual(self.project.server_status, HostedProject.ServerStatus.ONLINE)
        self.assertEqual(self.project.downtime_count, 0)
        self.assertFalse(self.project.incidents.filter(status="open").exists())
